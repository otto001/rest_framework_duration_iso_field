# rest_framework_duration_iso_field

## DurationIsoField
parses and serializes iso8601 <-> datetime.timedelta

## Caveats
- does not support date ranges
- does not support years/months
- does not support embedded dates
